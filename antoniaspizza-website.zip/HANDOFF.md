# Antonia's Pizza — website handoff

Everything another developer (or another AI tool) needs to pick this up cold.
Last updated: 2026-09-11.

---

## 1. What this is

A static marketing site for **Antonia's Pizza** — two locations on California's
Central Coast. Meant to be deployed at `antoniaspizza.com`.

- **Vanilla HTML + CSS + JS. No framework, no build step, no npm, no CDN.**
- Fonts are self-hosted `.woff2`. Nothing is fetched at runtime.
- Drop the folder on any static host (Netlify, Vercel, Cloudflare Pages, S3,
  cPanel) exactly as it is. No compile, no install.
- Visual direction is modelled on **pinza.com** — oversized display type, flat
  bright colour blocks, scrolling marquees, one signature interactive moment.

### Business facts baked into the pages
| | San Luis Obispo | Paso Robles |
|---|---|---|
| Address | 891 Higuera St, SLO, CA 93401 | 729 12th St, Paso Robles, CA 93446 |
| Phone | (805) 439-2383 | (805) 238-1851 |
| Late close | Thu–Sat till 2 AM | Fri–Sat till 2 AM |

Ordering goes to Toast: `https://antoniaspizza.toast.site/`
Signature items: pies from **10" to 28"**, and the **Ajarski** (Georgian-style
dough boat — mozzarella, feta, egg, butter).

---

## 2. File map

```
antonias/
├── index.html              home — hero, story, pie wheel, ajarski, deals, reviews, locations
├── menu.html               full menu (~38 dishes)
├── san-luis-obispo.html    location page
├── paso-robles.html        location page
├── standalone.html         GENERATED — do not hand-edit (see §3)
├── css/style.css           the entire design system, ~1000 lines, single file
├── js/main.js              all interactions, ~380 lines, one IIFE
├── favicon.svg
├── robots.txt / sitemap.xml
└── assets/
    ├── fonts/              8 self-hosted woff2 (Baloo 2 ×4, Anton, Sora ×3)
    └── img/
        ├── wheel/          the 8 pie-wheel slices — one per dish, all distinct
        └── *.jpg/png       everything else, incl. logo.png (transparent, circle-cropped)
```

`build.py` sits one level up, beside the `antonias/` folder.

---

## 3. The one build rule

`standalone.html` is a **generated** single-file copy of `index.html` with CSS,
JS, fonts and images inlined as data URIs, so the site can be opened straight
from disk with no server. It is useful for previewing and for emailing to
someone, and it is **not** what you deploy.

After editing `index.html`, `css/style.css` or `js/main.js`:

```bash
python build.py
```

Never edit `standalone.html` by hand — the next build overwrites it, and a
hand-edit that only lives there silently diverges from the real site. This has
already bitten this project once.

To preview locally:

```bash
python -m http.server 8777 --directory antonias
```

---

## 4. Design system

All tokens live in `css/style.css`. **Heads-up: there are two consecutive
`:root` blocks and the second overrides most of the first.** The second block is
the live palette; the first is leftover from an earlier warm-cream direction and
should be consolidated (see §7).

```css
/* the palette that is actually in effect */
--sky:   #bfe3f2;   --sky-2: #d8eff9;   /* page ground */
--sun:   #ffd23f;   --sun-2: #ffde6b;   /* primary accent, CTAs */
--navy:  #0e3a52;   --navy-2:#0a2c3f;   /* text + dark sections */
--paper: #fffdf7;                       /* cards, light sections */
--red:   #e2492f;                       /* stats, emphasis */
--gold:  #e8a33d;                       /* wheel section ground */

--font-display: "Baloo 2", "Sora", system-ui, sans-serif;
--font-body:    "Baloo 2", "Sora", system-ui, sans-serif;
/* "Anton" is loaded and available for a condensed display alternative */

--dur-1:.18s  --dur-2:.34s  --dur-3:.6s  --dur-4:.9s
--ease-soft: cubic-bezier(.22,1,.36,1)
--ease-snap: cubic-bezier(.34,1.56,.64,1)
--radius: 32px
--container: min(1240px, 92vw)
```

### Two rules that are easy to break

**1. `html.js` gating.** An inline script in every `<head>` adds `.js` to
`<html>`. Scroll-reveal rules are written as `html.js .reveal{opacity:0}` so
that **if JavaScript never runs, the content stays visible** instead of the page
going blank. If you add a reveal-style rule, gate it the same way.

**2. That gating raises specificity to (0,2,1).** Any rule meant to override a
reveal — above all the `prefers-reduced-motion` block — must match that weight
(`html.js .reveal`) and use `!important`. A bare `.reveal` selector is (0,1,0),
loses the cascade, and silently does nothing. This exact mistake disabled
reduced-motion support site-wide until it was caught.

---

## 5. Interactions in `js/main.js`

One IIFE, top to bottom. `$` and `$$` are `querySelector` / `querySelectorAll`
helpers. The whole script runs on all four pages, so **every lookup must be
null-safe** — an unguarded `querySelector(...).x` throws and kills every feature
declared after it.

| Feature | Notes |
|---|---|
| Preloader | Fake percentage counter. Strongly consider deleting it — see §7. |
| Custom cursor | Dot + ring; pointer-fine only |
| Header shrink / hide | Scroll listener |
| Scroll reveals | IntersectionObserver adds `.in` to `.reveal` / `.stagger` |
| Number counters | `[data-count]`, 1600 ms |
| Hero parallax | Scroll + mouse |
| Card tilt | Composes on top of the element's existing inline transform and restores it on leave |
| Magnetic buttons | rAF-batched, rect cached on enter |
| FAQ accordion | `max-height` transition |
| Location tabs | |
| Open/Closed pill | Reads a per-day schedule; handles the after-midnight tail (see §6) |
| Marquees | `track.innerHTML += track.innerHTML` for a seamless loop |
| Review scroller | Drag to scroll |
| **Pie wheel** | The signature piece — 8 slices, auto-rotate, click, drag-to-spin |

### Reduced motion
`motionMQ` is a live `MediaQueryList`. Register a reaction with
`onMotionChange(fn)`; `prefersReduced` is a `let` that updates on change, so read
it at call time — do not copy it into a `const` at startup.

---

## 6. The pie wheel

The most fragile and most valuable component. `index.html` → `.pie-rotor`.

- Exactly **8 `.slice` elements**, each rotated `n × 45deg`, each with a
  counter-rotated `<img style="--r:-{n×45}deg">` so the photo stays upright.
- Each slice carries `data-name` (label shown in the centre disc and at the side)
  and `data-craving` (the word swapped into the "i'm craving ___" headline).
- **All 8 images must be different.** They previously were not: two slices shared
  `ajarski-2.jpg`, and `grill.jpg` / `pies-3.jpg` and `deli.jpg` / `pies-4.jpg`
  were byte-identical duplicates under different names. Current set lives in
  `assets/img/wheel/` and is verified distinct by hash.
- **Labels must match what the photo actually shows.** The image filenames
  inherited from `antoniaspizza.com` are unreliable — `ajarski-boat.png` is a
  pasta dish, `ajarski-four.png` is a cocktail glass. Look at the picture before
  naming the slice.
- `goTo(i)` travels the **shortest signed path**
  (`rot += mod(want - rot + 180, 360) - 180`). Setting an absolute angle makes
  the 8→1 wrap unwind 315° backwards, which looks broken.
- Autoplay is gated on an IntersectionObserver (`onScreen`) so the timer does not
  run — and force a reflow every 4.2 s — while the wheel is off screen.

### Open/Closed pill
Hours are `[open, close]` in minutes-from-midnight per weekday. **A `close`
value above 1440 means the shift spills into the next day** (1560 = 2 AM). At
00:30 the date has already rolled over, so the still-running shift belongs to
*yesterday's* row — `main.js` checks that tail explicitly. Without it the site
reads "Closed" during exactly the late-night hours the shop is known for.

---

## 7. Known issues — not yet fixed

A 5-way audit found 95 issues; the critical correctness ones are fixed. These
remain, roughly in priority order.

**Content**
1. Most food photography is AI-generated stock, not the real restaurant. Several
   pizza shots share one identical styled background (basil plant + oil bottle).
   Real photos would lift the site more than any code change here.

**Performance**
3. The preloader gates first paint on a fake `Math.random()` timer for roughly
   2 s. Worse, the hero headline's entrance animation plays *behind* it and is
   never seen. Recommended: delete the preloader, and trigger the hero animation
   off `body.loaded` (the class is already added — nothing listens for it).
4. Hero LCP image has no `fetchpriority="high"` and queues behind two logo PNGs.
5. `will-change` on `.btn` and `.reveal` is never released — ~30 permanent
   compositor layers.
6. `backdrop-filter` on the sticky header re-blurs the viewport every scroll frame.

**Accessibility**
7. The pie wheel is unreachable by keyboard. `tabindex="-1"` is on each slice as
   groundwork; it still needs roving-tabindex arrow-key handling.
8. Auto-rotating wheel and infinite marquees have no pause control (WCAG 2.2.2,
   Level A).
9. Mobile nav links stay focusable while the menu is closed.
10. The gallery marquee is duplicated by JS and read out twice by screen readers —
    the clone needs `aria-hidden="true"`.

**Responsive**
11. The pie-wheel centre disc renders as an oval on phone widths.
12. The spinning "ORDER NOW" badge overlaps and intercepts taps on the hero eyebrow.

**Code health**
14. Consolidate the two `:root` blocks into one.
15. Several `@keyframes` are defined but unused; some classes are styled but
    never appear in any HTML.
16. The four pages duplicate a large `<head>`, header and footer. Some of it has
    already drifted apart between pages.

---

## 8. Recent changes (this session)

Fixed:
- JS `})();` was misplaced mid-file — everything after it threw
  `ReferenceError: $$ is not defined`, killing the wheel and all later features.
- `overflow-x:hidden` on `body` made body its own scroll container and broke
  vertical scrolling. Now `overflow-x:clip` on `html`.
- `prefers-reduced-motion` never applied (specificity, see §4 rule 2).
- `.reveal-left` / `-right` / `-zoom` were inert; the reset rule targeted
  `.in-reveal-*`, a class that exists nowhere.
- Pie wheel whipped 315° backwards on every wrap-around.
- Open/Closed pill reported "Closed" between midnight and 2 AM.
- Locations section rendered navy text on a near-black inline background —
  1.42:1 contrast, illegible. The inline style was overriding the stylesheet.
- Card tilt permanently destroyed the inline rotation on the deal cards.
- Duplicate element IDs (`lgif-top`, `lgif-bot`) in the header and footer logos.

Added:
- Site-wide `:focus-visible` ring (there was none).
- Press/active states (there were 28 hover states and zero press states).
- Scroll choreography layer using native `animation-timeline: view()` /
  `scroll()`, wrapped in `@supports` and fully disabled under reduced motion.
- Reading-progress rail at the top of every page.
- The real brand logo, circle-cropped with a proper alpha mask. The source file
  the owner supplied is RGB with the transparency checkerboard **baked into the
  pixels** — it must be masked, not just dropped in.
- `build.py`, so `standalone.html` stops drifting from source.

### Menu page (second pass)
- **Prices are deliberately absent.** The owner does not want them on the site,
  so the dead `.mi-price` rules were removed rather than left as a trap. Do not
  invent prices for a real restaurant.
- Sticky category rail: 8 chips, each a 44px touch target, horizontally
  scrollable, with `aria-current="true"` following the section you are reading.
  The rail auto-scrolls the active chip into view — scroll the inner
  `.menu-rail-inner`, not the `<nav>`, which does not scroll.
- `--header-h` is now published from JS (the header is fixed and shrinks on
  scroll, so the rail's `top` and the sections' `scroll-margin-top` need the
  live value, not a guess).
- Item stagger is `0.03s` per item over `300ms`. Card grids use `0.06s`.
  Both come from the ui-ux-pro-max motion data: `0.02-0.04s` per item for long
  lists, never past `0.1s`. The old ladder was `0.1s` — right at that limit.
- Card entrances use a slight overshoot (`--ease-snap`) with `scale(.92)` and a
  16px rise, matching the Standard stagger tier for a playful consumer brand.
- `.menu-item--feature` no longer pins a 220px column; it collapses to one
  column under 560px. It previously crushed its text to ~80px on a 360px phone.

---

## 8b. The two spin-to-decide wheels (`#spin` on index.html)

Separate from the pie carousel in §6. Both are built from one CSS disc
(`conic-gradient`) plus a `transform` spin — no canvas, no library.

**Wheel 1 — "Pick my pizza."** Picks one of eight pies at random.
**Wheel 2 — "Spin for a treat."** One prize per visitor.

### How a landing angle is computed
Eight segments, pointer fixed at 12 o'clock. Segment `i` covers
`[i*45, (i+1)*45)` clockwise from the top, so landing on `i` means rotating the
disc to `-(i*45 + 22.5)` degrees, minus 5–7 whole turns for the spin. The result
shown is always the segment under the pointer — verified across repeated spins.
If you change the number of segments, change the `conic-gradient` stops, the
`--seg` value in CSS, and nothing else: the JS derives everything from the item
count.

### Editing the prizes — read this before launch
The prize copy in `index.html` (`data-spin-items` on the prize wheel) is a
**starting suggestion, not the owner's confirmed offer list.** Free drink, 10%
off, garlic knots, free topping, $5 off, cannoli, and two "try again" segments.
Replace them with the real offers before the site goes live. Each entry is
`{"name":"...","note":"...","win":true|false}` — `win:false` renders the muted
"no prize" card.

### What the once-per-visitor lock actually is
`localStorage` under the key in `data-spin-once`. It stops casual re-spinning
and survives a refresh, and that is all it does. **It is not enforcement.**
Anyone can clear site data, open a private window, or read the prize list
straight out of the page source. Do not put an offer on this wheel that you
would not be willing to honour for anyone who asks. Real, controlled promo
codes need a backend or the Toast promotions system.

### Accessibility
The result card is a `role="status" aria-live="polite"` region, so the outcome is
announced. Under `prefers-reduced-motion` the disc does not spin at all — it
jumps straight to the landing angle and renders the result. Prize-wheel labels
on the red segments use paper ink: navy on that red measures 2.99:1 and fails AA
for large text, paper measures 3.95:1 and passes.

---

## 8c. Version control

The project is a git repo. `standalone.html` is **git-ignored** — it is
generated, and committing it would bury every real diff under 4MB of base64.
Rebuild it with `python build.py` after pulling.

Every change from here lands as its own commit, so `git log` is the changelog
and any step can be reverted on its own.

## 8d. Hero overture, size comparer, word reveals

**Hero.** The entrance used to start the moment CSS parsed, while the preloader
still covered the screen for about two seconds — so no visitor ever saw it.
`main.js` was already adding `body.loaded` when the preloader cleared and
nothing in CSS listened for it. The whole hero sequence now hangs off that
class: eyebrow at 0.04s, headline lines at 0/0.1/0.2s, photo at 0.30s, sub at
0.46s, buttons at 0.56s, stats at 0.66s, and a one-off shine sweep across the
primary CTA at 1.35s. Without JS the `html.js` gate never applies and every
hero element simply sits in place, readable.

**Size comparer (`#sizes`).** A slider from 10" to 28" next to a dinner plate
drawn at true relative scale — the pie's width is `(inches / 28)` of the stage
cap and the plate is `10.6 / 28` of the same, so the proportions are honest
rather than decorative. Verified: 10" renders 86px, 28" renders 242px, a ratio
of 2.80 against an expected 28/10 = 2.80.

**Word-by-word headlines.** `splitWords()` walks **text nodes only** via a
TreeWalker. This matters: the headings contain `.text-outline`, `.hl` (which
carries its highlighter bar as a `::after`), and `.craving-word`, and a naive
`innerHTML.split(" ")` would destroy all of them. 0.045s per word.

**Hover states no longer animate layout.** Four rules animated `padding-left`
on hover — a layout property, so every pointer pass triggered reflow. All four
now use `transform: translateX()`.

---

## 9. If you continue this on another platform

Paste §1 and §4 as context, then say what you want changed. The constraints that
matter most, and that a fresh tool will otherwise violate:

1. Vanilla only — no React, no Tailwind, no build step, no CDN.
2. Keep the `html.js` gating, and match its (0,2,1) specificity in any override.
3. Every `querySelector` in `main.js` must be null-safe — one script, four pages.
4. Animate transform/opacity/filter only.
5. Run `python build.py` after touching `index.html`, `style.css` or `main.js`.
6. All 8 pie-wheel images stay distinct, and labels match the photo content.
