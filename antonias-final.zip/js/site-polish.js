(() => {
  'use strict';
  const current = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(link => {
    const destination = new URL(link.href);
    if (!destination.hash && destination.pathname.split('/').pop() === current) link.setAttribute('aria-current', 'page');
  });
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'back-to-top';
  button.textContent = '↑';
  button.setAttribute('aria-label', 'Back to top');
  button.hidden = true;
  document.body.append(button);
  let queued = false;
  function update() {button.hidden = window.scrollY < 800; queued = false;}
  window.addEventListener('scroll', () => {if (!queued) {queued = true; requestAnimationFrame(update);}}, {passive: true});
  button.addEventListener('click', () => {
    const target = document.querySelector('.skip-link');
    target?.focus({preventScroll: true});
    window.scrollTo({top: 0, behavior: document.documentElement.classList.contains('reduce-motion') ? 'instant' : 'smooth'});
  });
  update();
})();
