/* Apply the saved preference before the first paint and page transition. */
(() => {
 const policy=document.createElement('style');policy.id='motion-nav-policy';document.head.append(policy);
 function refresh(){
  let paused=document.documentElement.classList.contains('motion-paused');try{paused=sessionStorage.getItem('antonias-motion-paused')==='true';}catch{}
  const reduced=paused||matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.documentElement.classList.toggle('reduce-motion',reduced);document.documentElement.classList.toggle('motion-paused',reduced);
  policy.textContent=reduced?'@view-transition {navigation: none;}':'';return reduced;
 }
 refresh();
 const skip=event=>{if(refresh())event.viewTransition?.skipTransition();};
 addEventListener('pageswap',skip);addEventListener('pagereveal',skip);
})();
