/* Small, local-only helpers for choosing a meal. */
(() => {
  'use strict';
  const catalog = [
    {id:'special',name:'Antonia’s Special',mood:'meaty',image:'pizza-picker/special.webp',query:"Antonia's Special",note:'Pepperoni, mushrooms, red onion, bacon and pepperoncini.'},
    {id:'supreme',name:'Deluxe Supreme',mood:'meaty',image:'pizza-picker/supreme.webp',query:'Deluxe Supreme',note:'Pepperoni, sausage, mushrooms, peppers, red onion and olives.'},
    {id:'cheesesteak',name:'Cheese Steak',mood:'meaty',image:'menu-cutouts/cheesesteak-v2-480.webp',query:'Cheese Steak',note:'A warm sandwich for your next comfort-food craving.'},
    {id:'margherita',name:'Original Margherita',mood:'cheesy',image:'pizza-picker/margherita.webp',query:'Original Margherita',note:'Fresh mozzarella, fresh basil and homemade tomato sauce.'},
    {id:'ajarski',name:'Ajarski Original',mood:'cheesy',image:'menu-cutouts/ajarski-480.webp',query:'Ajarski Original',note:'Mozzarella, feta, egg and butter in a warm bread boat.'},
    {id:'hawaiian',name:'Hawaiian',mood:'cheesy',image:'pizza-picker/hawaiian.webp',query:'Hawaiian',note:'Canadian bacon and pineapple on a golden crust.'},
    {id:'caesar',name:'Caesar Salad',mood:'fresh',image:'menu-cutouts/salad-480.webp',query:'Caesar Salad',note:'Romaine, croutons and parmesan for a fresh change of pace.'},
    {id:'mediterranean',name:'Mediterranean',mood:'fresh',image:'pizza-picker/mediterranean.webp',query:'Mediterranean',note:'Pesto, artichokes, olives, sun-dried tomatoes and feta.'},
    {id:'fresh-margherita',name:'Original Margherita',mood:'fresh',image:'pizza-picker/margherita.webp',query:'Original Margherita',note:'Keep it simple with fresh mozzarella and basil.',favoriteId:'margherita'}
  ];
  const section=document.querySelector('[data-discovery]');
  if(section){
    const grid=section.querySelector('[data-craving-grid]'),buttons=Array.from(section.querySelectorAll('[data-mood]'));
    const savedList=section.querySelector('[data-favorites]'),status=section.querySelector('[data-discovery-status]');
    const key='antonias-favorites-v1';let favorites=[];
    try {const value=JSON.parse(localStorage.getItem(key)||'[]');if(Array.isArray(value))favorites=value.filter(id=>catalog.some(d=>d.id===id)).slice(0,8);}catch{}
    let mood='cheesy';
    const linkFor=d=>'menu.html?q='+encodeURIComponent(d.query)+'#dish-search';
    function updateSaved(){
      savedList.replaceChildren();
      if(!favorites.length){const p=document.createElement('p');p.textContent='Save a dish to keep your next order handy on this device.';savedList.append(p);return;}
      favorites.forEach(id=>{
        const dish=catalog.find(d=>d.id===id);if(!dish)return;
        const row=document.createElement('div'),link=document.createElement('a'),remove=document.createElement('button');
        link.textContent=dish.name;link.href=linkFor(dish);remove.type='button';remove.textContent='Remove';remove.setAttribute('aria-label','Remove '+dish.name+' from favorites');
        remove.addEventListener('click',()=>{toggle(id);remove.isConnected?remove.focus():section.querySelector('[data-saved-title]').focus();});
        row.append(link,remove);savedList.append(row);
      });
    }
    function toggle(id){
      favorites=favorites.includes(id)?favorites.filter(value=>value!==id):[...favorites,id];
      let persisted=true;
      try{localStorage.setItem(key,JSON.stringify(favorites));}catch{persisted=false;}
      updateSaved();
      grid.querySelectorAll('[data-save]').forEach(button=>{const saved=favorites.includes(button.dataset.save);button.setAttribute('aria-pressed',String(saved));button.textContent=saved?'Saved ♥':'Save ♡';});
      status.textContent=favorites.length+' saved '+(favorites.length===1?'dish':'dishes')+'.'+(persisted?'':' Browser storage is unavailable; saved for this visit only.');
    }
    function render(){
      buttons.forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.mood===mood)));
      grid.replaceChildren();
      catalog.filter(d=>d.mood===mood).forEach(dish=>{
        const card=document.createElement('article'),image=document.createElement('img'),title=document.createElement('h3'),note=document.createElement('p'),actions=document.createElement('div'),link=document.createElement('a'),save=document.createElement('button');
        card.className='craving-card';image.src='assets/img/'+dish.image;image.alt=dish.name;image.width=480;image.height=480;image.loading='lazy';image.decoding='async';
        title.textContent=dish.name;note.textContent=dish.note;link.textContent='Find on the menu ↗';link.href=linkFor(dish);
        save.type='button';save.dataset.save=dish.favoriteId||dish.id;save.setAttribute('aria-label','Save '+dish.name);save.setAttribute('aria-pressed',String(favorites.includes(save.dataset.save)));save.textContent=favorites.includes(save.dataset.save)?'Saved ♥':'Save ♡';save.addEventListener('click',()=>toggle(save.dataset.save));
        actions.className='craving-actions';actions.append(link,save);card.append(image,title,note,actions);grid.append(card);
      });
    }
    buttons.forEach(button=>button.addEventListener('click',()=>{mood=button.dataset.mood;render();status.textContent='3 suggestions for '+button.textContent.trim()+'.';}));
    section.hidden=false;render();updateSaved();
  }
  const planner=document.querySelector('[data-party-planner]');
  if(planner){
    const count=planner.querySelector('input'),appetite=planner.querySelector('select'),result=planner.querySelector('[role=status]');
    function update(){
      const guests=Math.min(20,Math.max(1,Number(count.value)||1));
      // A 16-inch pizza is a planning baseline for 3 regular or 2 hungry eaters.
      const capacity=appetite.value==='hungry'?2:3, pies=Math.ceil(guests/capacity);
      result.textContent='For '+guests+' '+(guests===1?'person':'people')+', start with '+pies+' × 16-inch '+(pies===1?'pizza':'pizzas')+'. Adjust for appetite and sides.';
    }
    count.addEventListener('input',update);appetite.addEventListener('change',update);planner.hidden=false;update();
  }
})();
